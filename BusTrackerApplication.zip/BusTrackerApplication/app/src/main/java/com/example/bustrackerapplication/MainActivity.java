package com.example.bustrackerapplication;

import android.app.Activity;

public class MainActivity extends Activity {
}
