// BusTrackingActivity.java
package com.example.bustrackerapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;

public class BusTrackingActivity extends AppCompatActivity {

    private SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_tracking);

        sp = getSharedPreferences("Bus Location", Context.MODE_PRIVATE);

        // Retrieve bus location updates
        updateBusLocationOnMap();
    }

    private void updateBusLocationOnMap() {
        double latitude = sp.getFloat("latitude", 0);
        double longitude = sp.getFloat("longitude", 0);

        // Update UI or map with the new location
        // Implement your logic here

        Toast.makeText(this, "Bus Location Updated: " + latitude + ", " + longitude, Toast.LENGTH_SHORT).show();
    }
}
