package com.example.bustrackerapplication;


public class Bus {
    private double latitude;
    private double longitude;

    public Bus() {
        // Default constructor required for SharedPreferences
    }

    public Bus(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }
}
