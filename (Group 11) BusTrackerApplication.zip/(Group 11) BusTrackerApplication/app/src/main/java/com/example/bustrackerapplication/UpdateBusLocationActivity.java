package com.example.bustrackerapplication;

import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;


public class UpdateBusLocationActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_bus_location);

        sharedPreferences = getSharedPreferences("BusLocation", Context.MODE_PRIVATE);

        // Example: Update bus location every 5 seconds
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Get the bus location (replace with your logic)
                double newLatitude = 12.345;
                double newLongitude = 67.890;

                // Update bus location in SharedPreferences
                updateBusLocation(newLatitude, newLongitude);

                // Repeat the task
                handler.postDelayed(this, 5000); // 5 seconds
            }
        }, 0);
    }

    private void updateBusLocation(double latitude, double longitude) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat("latitude", (float) latitude);
        editor.putFloat("longitude", (float) longitude);
        editor.apply();
    }
}
