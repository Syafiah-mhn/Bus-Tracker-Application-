package com.example.bustrackerapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SplashScreen extends AppCompatActivity {
    ImageView Roadmap;
    TextView text1, text2;
    Button btn1;

    Animation Top_anim, Bottom_anim, Left_anim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        Roadmap = findViewById(R.id.roadmap);
        text1 = findViewById(R.id.text1);
        text2 = findViewById(R.id.text2);
        btn1 = findViewById(R.id.btn1);

        Top_anim = AnimationUtils.loadAnimation(this, R.anim.topanim);
        Bottom_anim = AnimationUtils.loadAnimation(this, R.anim.bottomanim);
        Left_anim = AnimationUtils.loadAnimation(this, R.anim.leftanim);

        // Set animation listeners to handle the button visibility
        Top_anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                // Animation start logic
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                // Animation end logic
                btn1.setVisibility(View.VISIBLE); // Make the button visible after animations end
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // Animation repeat logic
            }
        });

        Roadmap.setAnimation(Top_anim);
        text1.setAnimation(Left_anim);
        text2.setAnimation(Bottom_anim);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open next activity when the button is clicked
                Intent intent = new Intent(SplashScreen.this, SignupActivity.class);
                startActivity(intent);
            }
        });

    }

}
